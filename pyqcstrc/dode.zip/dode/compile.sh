python setup.py build_ext --inplace
